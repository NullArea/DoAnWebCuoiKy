
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="//fonts.googleapis.com/css?family=Playball" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
<!--slider-->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/script.js')); ?>" type="text/javascript"></script>
<base href="<?php echo e(asset('')); ?>">

<style>
#fixNav{
	width: 100%;
	height: 35px;
	background-color: #0082bb;
	display: block;
	top: 0;
	left: 5px;
}
#fixNav ul{
	margin: 0;
	padding: 10px;
}
#fixNav ul li{
	list-style: none inside;
	width: auto;
	float: left;
	line-height: 35px;
	color: #fff;
	padding: 0;
	margin-right: 10px;
	position: relative;
}
#fixNav ul li a{
	text-transform: uppercase;
	white-space: nowrap;
	padding: 0 10px;
	color: #fff;
	display: block;
	font-size: 0.8em;
	text-decoration: none;
}
#fixNav ul li ul{
	position: absolute;
	width: auto;
	display: none;
	background-color: #252525;
	border-bottom: 3px solid #0082bb;
	padding-left: 5px;
}
#fixNav ul li ul li{
	display: block;
	padding:0;
	margin: 0;
    float: none;
}
#fixNav ul li:hover{
	background-color: #252525;
}
#fixNav ul li:hover ul{
	display: block;
}
</style>
