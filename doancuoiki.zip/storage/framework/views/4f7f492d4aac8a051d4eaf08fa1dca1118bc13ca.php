<title>Management Moto-Heart</title>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4 addproducts">
            Add
        </div>
        <div class="col-md-4 addproducts">
            Update
        </div>
        <div class="col-md-3 addproducts">
            Drop
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>