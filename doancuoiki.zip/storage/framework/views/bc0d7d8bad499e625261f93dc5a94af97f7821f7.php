<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-top">
            <div class="about_wrapper"><h1>Choose one you want!</h1>
            </div>
           
            <div class="text">
                <?php $__currentLoopData = $allproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="grid_1_of_3 images_1_of_3">
                    <div class="grid_1">
                        <a href="<?php echo e(route('detail',$product->stt)); ?>"><img src="<?php echo e($product->hinh); ?>" title="continue reading" alt=""></a>
                        <div class="grid_desc">
                            <p class="title"><?php echo e($product->tenxe); ?></p>

                            <div class="price" style="height: 19px;">
                                <span class="reducedfrom"><?php echo e($product->gia); ?>$</span>
                                <span class="actual">00$</span>
                            </div>
                            <div class="cart-button">
                                <div class="cart">
                                    <button class="button"><span>Details</span></button>
                                </div>
                                <button class="button"><span>Cart</span></button>
                                <div class="clear"></div>
                            </div>
                        </div>
                    </div><div class="clear"></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
            </div>
            <div class="clear"></div>
            <div><?php echo e($allproduct->links()); ?> </div>                   
        </div>
        
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>