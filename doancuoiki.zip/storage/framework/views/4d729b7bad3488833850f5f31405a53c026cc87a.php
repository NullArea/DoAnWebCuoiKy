<title><?php echo $__env->yieldContent('title'); ?>Log-In</title>
<?php $__env->startSection('content'); ?>
    i am the login page
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>