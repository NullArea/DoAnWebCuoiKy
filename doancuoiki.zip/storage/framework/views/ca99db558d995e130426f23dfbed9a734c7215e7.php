
<a id="go-top" href="javascript:;"><i class="spr spr--goTop"></i><span>Top</span></a>
 
	    <div class="wrapper category_page">
	        

			<div class="header">
			    <div class="l-grid">
			        <a href="/" class="logo-color"></a>
			        <form class="global-search">
			            <input type="text" placeholder="Nhập nội dung tìm kiếm">
			            <button><i class="spr spr--search"></i></button>
			        </form>
			        <div class="header__action">
			            <a class="login" href="javascript:;" data-animation="none" data-animationspeed="0" data-reveal-id="login-modal">
			                <i class="spr spr--login"></i>
			                <span>Đăng nhập</span>
			            </a>
			            <p class="has-logged" style="display: none"></p>
			            <a href="javascript:;" data-target-host="//m.baomoi.com" class="mobile"><i class="spr spr--mobile"></i><span>Bản mobile</span></a>
			        </div>
			    </div>
			</div>


			<div class="nav-wrap">
			    <div class="nav">
			        <div class="l-grid">
			            <ul>
			                <li class="nav__parent has-icon">
			                    <a href="/">
			                        <i class="spr spr--home"></i>
			                    </a>
			                </li>
			                
			                        <li class="nav__parent">
			                            <a href="/products" data-id="121">Products</a>
			                            
			                                    <ul class="nav__child">
			                                
			                                    <li>
			                                        <a href="/Kawasaki" data-id="144">Kawasaki</a>
			                                    </li>
			                                
			                                    <li>
			                                        <a href="/Honda" data-id="4">Honda</a>
			                                    </li>
			                                
			                                    <li>
			                                        <a href="/Yamaha" data-id="3">Yamaha</a>
			                                    </li>
			                                </ul>
			                        </li>
			                    
			                        <li class="nav__parent">
			                            <a href="/about" data-id="119">About</a>
			                            
			                        </li>
			                    
			                        <li class="nav__parent">
			                            <a href="/contact" data-id="54">Contact</a>
			                            
			                                    <ul class="nav__child">
			                                
			                                    <li>
			                                        <a href="/nkTanQuy" data-id="15">9 Tan Quy</a>
			                                    </li>
			                                
			                                    <li>
			                                        <a href="/nkDucMinh" data-id="84">492 Tan Ky Tan Quy</a>
			                                    </li>
			                                
			                                    <li>
			                                        <a href="/nkCali" data-id="137">662/6a Su Van Hanh</a>
			                                    </li>
			                                </ul>
			                        </li>
			                    
			                    
			                        <li class="nav__parent">
			                            <a href="/xe-co.epi" data-id="145">Tin xe</a>
			                            
			                        </li>
			                			                    
			                <li class="nav__parent is-last">
			                    <a href="javascript:;">
			                        <i class="spr spr--search"></i>
			                    </a>
			                </li>
			            </ul>
			        </div>
			    </div>
			</div>
		</div>
	