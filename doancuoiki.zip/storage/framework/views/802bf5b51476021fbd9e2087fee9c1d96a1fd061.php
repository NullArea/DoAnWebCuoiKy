
<div id="footer">
	<div id="block1">
		<div id="blockleft">
			<h2><strong>Tran Ngoc Anh</strong></h2>
			<h3>227 Nguyễn Văn Cừ, phường 4, quận 5, TP.HCM</h3>
			<h3>© Copyright 2017 NA Company</h3>
		</div>
		<div id="map"></div>
			<script>
				function myMap() {
					var mapCanvas = document.getElementById("map");
					var mapOptions = {
						center: new google.maps.LatLng(10.762639092330923,106.68199999999999), zoom: 15
					};
					var map = new google.maps.Map(mapCanvas, mapOptions);
				}
			</script>
			<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBzUiwecG-pkEEtg-0K-UQ_QUGBNHSF8RU&callback=myMap"></script>
	</div>
</div>