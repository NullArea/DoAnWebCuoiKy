<!doctype html>
<html>
<head>
    <?php echo $__env->make('includes.adhead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>   
</head>
<body>
    <?php echo $__env->make('includes.adbody', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>