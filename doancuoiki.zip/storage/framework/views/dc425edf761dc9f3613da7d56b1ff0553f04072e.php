<title><?php echo $__env->yieldContent('title'); ?>About NAC</title>
<?php $__env->startSection('content'); ?>
    <h1>News Hear!</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>