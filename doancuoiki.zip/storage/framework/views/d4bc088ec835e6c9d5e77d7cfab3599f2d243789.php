<?php $__env->startSection('title', 'Detail of Products'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-top">
            <div class="about_wrapper">
                <h1><?php echo e($product->tenxe); ?></h1>
                <h3>Edition <?php echo e($product->namsx); ?> - <?php echo e($product->gia); ?>$</h3>
            </div>
            <img src="<?php echo e($product->hinh); ?>">
            <p><?php echo e($product->mota); ?></p>            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>