
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="//fonts.googleapis.com/css?family=Playball" rel="stylesheet" type="text/css">
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/script.js')); ?>" type="text/javascript"></script>
<base href="<?php echo e(asset('')); ?>">
<title><?php echo $__env->yieldContent('title'); ?></title>   
