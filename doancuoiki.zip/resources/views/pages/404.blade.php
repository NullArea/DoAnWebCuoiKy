<div class="banner-top">
    <div class="header-bottom">
        <div class="page-not-found">
            <h1>404</h1>
        </div>
        <div class="footer-bottom">
            <div class="copy">
                <p>Phone: +84962408090</p>
			    <p>Headquarters: 227 Nguyen Van Cu, Ward 4, District 5, HCM</p>
			    <p>&copy 2017 Motor Heart . All rights Reserved | Design by <a href="https://www.facebook.com/tnanh.fit">Ngọc Anh</a></p>
            </div>
        </div>
    </div>
</div>