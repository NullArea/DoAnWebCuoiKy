@extends('layouts.admin')
<title>Management Moto-Heart</title>
@section('content')
    <div class="row">
        <div class="col-md-4 addproducts">
            Add
        </div>
        <div class="col-md-4 addproducts">
            Update
        </div>
        <div class="col-md-3 addproducts">
            Drop
        </div>
    </div>
@stop