@extends('layouts.default')
@section('title', 'Motor News')
@section('content')
    <h1>News Hear!</h1>
@endsection