@extends('layouts.default')
@section('title', 'Log-In')
@section('content')
    i am the login page
@endsection