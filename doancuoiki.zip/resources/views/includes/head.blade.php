
<link href="{{asset('css/style.css')}}" rel="stylesheet" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="//fonts.googleapis.com/css?family=Playball" rel="stylesheet" type="text/css">
<script src="{{asset('js/jquery.min.js')}}"></script>
<script src="{{asset('js/script.js')}}" type="text/javascript"></script>
<base href="{{asset('')}}">
<title>@yield('title')</title>   
