<div class="container">
    <div class="row">
        <div class="col-1">
        </div>
        <div class="col-10 topland">
            <img src="images/logo3.png" alt=""/>
        </div>
        <div class="col-1">
        </div>
    </div>
    @yield('content')
</div>