<!doctype html>
<html>
<head>
    @include('includes.adhead')   
</head>
<body>
    @include('includes.adbody')
</body>
</html>