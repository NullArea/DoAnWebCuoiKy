<!doctype html>
<html>
<head>
    @include('includes.head')
</head>
<body>
    @include('includes.body')
</body>
</html>